# Next Level Gaming & Esports Arena — Website Prototype

A beginner-friendly static website for a student project, built with HTML, CSS and JavaScript.

## Pages
- `index.html` — Home
- `about.html` — About Us
- `overview.html` — Experiences overview
- `package.html` — One individual/featured package page
- `calculate-fees.html` — Interactive example fee calculator
- `contact.html` — Contact information and demo enquiry form

## Run in VS Code
1. Extract the ZIP folder.
2. Open VS Code.
3. Select **File → Open Folder** and choose `next_level_gaming_website`.
4. Open `index.html`.
5. If you have the **Live Server** extension, right-click `index.html` and select **Open with Live Server**. Otherwise, open `index.html` in a browser.

## Before submission
- Replace example prices with group-approved prices.
- Replace placeholder contact information with verified details.
- Confirm that the final logo, colours and content match the group's Phase 3 decisions.
- The contact form is front-end only and does not send or store messages.
